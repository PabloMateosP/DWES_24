<?php

// Cargamos librería
include "lib/funciones.php";

// Cargamos model 
include "models/model.index.php";

// Cargamos vista
include "views/view.index.php";
    
?>