<?php

    /*
        Conexión MySQL con la clase mysqli

        constantes de conexión
    */

    # Definir las constantes de conexión

    define('SERVER', 'localhost');
    define('USER', 'root');
    define('PASS', null);
    define('BD', 'geslibros');

    define('CHARSET', 'utf8mb4');
    define('COLECCION', 'utf8mb4_unicode_ci');
    


?>