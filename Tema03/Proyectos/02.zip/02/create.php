<?php 

    // Cargamos librería
    include 'libs/crud_funciones.php';

    // Cargamos modelo
    include 'models/model.create.php';

    // Cargamos vista
    include 'views/view.index.php';

?>