

<?php $__env->startSection('titulo', 'Artículos'); ?>
<?php $__env->startSection('subtitulo', 'Listado de artículos'); ?>

<?php $__env->startSection('contenido'); ?>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="#">Inicio</a>
            <a class="navbar-brand" href="#">Artículos</a>
        </div>
    </nav>

    <table class="table">
        <thead>
            <tr>
                <th scope="col">⨀</th>
                <th scope="col">Descripción</th>
                <th scope="col">Categoría</th>
                <th scope="col">Unidades</th>
                <th scope="col">Precio Cost</th>
                <th scope="col">Precio Sell</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $articulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $articulo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($articulo->id); ?></th>
                    <td><?php echo e($articulo->descripcion); ?></td>
                    <td><?php echo e($articulo->categoria); ?></td>
                    <td><?php echo e($articulo->unidades); ?></td>
                    <td><?php echo e($articulo->precio_coste); ?></td>
                    <td><?php echo e($articulo->precio_venta); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <!-- Número de registros -->
    <p>Número de registros: <?php echo e(count($articulos)); ?></p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DWES\Tema12\Proyectos\08\laravel-08\resources\views/articulos/articulos.blade.php ENDPATH**/ ?>