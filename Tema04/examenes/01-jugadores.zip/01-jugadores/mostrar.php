<?php

// Cargamos clase 
include 'class/class.jugador.php';
include 'class/class.arrayJugadores.php';

// Cargamos modelo 
include 'models/model.mostrar.php';

// Cargamos vista
include 'views/view.mostrar.php';

?>