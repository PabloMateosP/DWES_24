<?php

// Cargamos librería
include "lib/funciones.php";

// Cargamos model 
include "models/model.create.php";

// Cargamos vista
include "views/view.index.php";
   
?>