<?php 

    // Cargamos libreria 
    include "libs/crud_funciones.php";

    // Cargamos el modelo
    include "models/model.mostrar.php";

    // Cargamos la vista 
    include "views/view.form_mostrar.php";

?>