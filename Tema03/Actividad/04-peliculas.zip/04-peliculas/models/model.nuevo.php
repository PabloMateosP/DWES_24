<?php

/*
    fichero: model.nuevo.php
    Descripción: modelo del proceso nuevo.php. 

*/
// Cargamos películas
$peliculas = getPeliculas();

// Cargamos array países 
$paises = getPaises();

// Cargamos array géneros 
$listGeneros = getGeneros();


?>