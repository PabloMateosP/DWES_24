<?php 

// Librería
include 'libs/crud_funciones.php';

// Model
include 'models/model.update.php';

// Cargo la vista
include "views/view.index.php";


?>