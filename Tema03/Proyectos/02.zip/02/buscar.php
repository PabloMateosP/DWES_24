<?php 

    # Cargamos modelo 
    include "models/model.buscar.php";

    # Cargamos vista
    include "views/view.index.php";

?>