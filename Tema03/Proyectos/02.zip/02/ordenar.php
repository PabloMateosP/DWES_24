<?php

// Librerías
include 'libs/crud_funciones.php';

// Model
include 'models/model.ordenar.php';

// Cargo la vista
include "views/view.index.php";

?>