<?php

// Cargamos clases
include 'class/class.jugador.php';
include 'class/class.arrayJugadores.php';

// Cargamos modelo 
include 'models/model.index.php';

// Cargamos vista 
include 'views/view.index.php';
    
?>