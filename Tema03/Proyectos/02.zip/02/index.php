<?php 

    // Cargamos libreria
    include 'libs/crud_funciones.php';

    //Cargamos modelo
    include "models/model.index.php";

    //Cargamos vista
    include "views/view.index.php";
    
?>