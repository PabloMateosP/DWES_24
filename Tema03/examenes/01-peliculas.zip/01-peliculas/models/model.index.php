<?php

/*
    fichero: model.index.php
    Descripción: modelo del proceso index.php

*/

// Cargamos array países 
$paises = getPaises();

// Cargamos array géneros 
$listGeneros = getGeneros();

// Cargamos array películas 
$peliculas = getPeliculas();



?>