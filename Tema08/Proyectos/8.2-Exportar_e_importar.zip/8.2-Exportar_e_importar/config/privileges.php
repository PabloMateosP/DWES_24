<?php
/*
    Perfiles	 	Nuevo	Editar	Eliminar	 Mostrar	Buscar 	Ordenar 
ADMINISTRADOR	 	SI	SI	SI	 SI	 SI	 SI
EDITOR	 	SI	SI	NO	 SI	 SI	SI 
REGISTRADO	 	NO	NO	NO	 SI	 SI 	 SI

*/

$GLOBALS['clientes']['main'] = [1, 2, 3];
$GLOBALS['clientes']['new'] = [1, 2];
$GLOBALS['clientes']['edit'] = [1, 2];
$GLOBALS['clientes']['delete'] = [1];
$GLOBALS['clientes']['show'] = [1, 2, 3];
$GLOBALS['clientes']['filter'] = [1, 2, 3];
$GLOBALS['clientes']['order'] = [1, 2, 3];
$GLOBALS['clientes']['export'] = [1];
$GLOBALS['clientes']['import'] = [1];

$GLOBALS['cuentas']['main'] = [1, 2, 3];
$GLOBALS['cuentas']['new'] = [1, 2];
$GLOBALS['cuentas']['edit'] = [1, 2];
$GLOBALS['cuentas']['delete'] = [1];
$GLOBALS['cuentas']['show'] = [1, 2, 3];
$GLOBALS['cuentas']['filter'] = [1, 2, 3];
$GLOBALS['cuentas']['order'] = [1, 2, 3];
$GLOBALS['cuentas']['export'] = [1];
$GLOBALS['cuentas']['import'] = [1];