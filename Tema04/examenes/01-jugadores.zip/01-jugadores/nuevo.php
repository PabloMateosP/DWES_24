<?php

// Cargamos clases
include 'class/class.jugador.php';
include 'class/class.arrayJugadores.php';

// Cargamos modelos
include 'models/model.nuevo.php';

// Cargamos vistas
include 'views/view.nuevo.php';

?>