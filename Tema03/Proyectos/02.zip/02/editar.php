<?php 

    // Librerias
    include 'libs/crud_funciones.php';

    // Cargamos modelo 
    include 'models/model.editar.php';

    // Cargamos vista
    include 'views/view.editar.php';

?>