<?php 

    /* Modelo para general tabla llamando a la función  */

    generar_Tabla();

?>