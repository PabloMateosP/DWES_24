<?php
# Configuración básica aplicación MVC

# Ruta absoluta
define('URL', 'http://localhost/DWES/Tema09/Proyectos/9.1-Exportar_pdf/');

# Constante de la Base de Datos
define('HOST', 'localhost');
define('DB', 'gesbank');
define('USER', 'root');
define('PASSWORD', '');
define('CHARSET', 'utf8mb4');