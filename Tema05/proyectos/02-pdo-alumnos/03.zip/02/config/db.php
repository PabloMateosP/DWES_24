<?php

    /*
        Conexión MySQL con la clase PDO

        constantes de conexión
    */

    # Definir las constantes de conexión

    define('SERVER', 'localhost');
    define('USER', 'root');
    define('PASS', null);
    define('BD', 'fp');

    define('CHARSET', 'utf8mb4');
    define('COLLECTION', 'utf8mb4_unicode_ci');
    


?>