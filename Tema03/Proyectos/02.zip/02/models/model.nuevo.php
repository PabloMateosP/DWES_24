<?php 

    $categorias = generar_Tabla_categoria();

?>