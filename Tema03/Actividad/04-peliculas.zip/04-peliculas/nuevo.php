<?php
    
    //Cargamos libreria
    include "lib/funciones.php";

    //Cargamos modelo 
    include "models/model.nuevo.php";

    //Cargamos vista
    include "views/view.nuevo.php";

?>