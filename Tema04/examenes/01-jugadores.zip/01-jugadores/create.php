<?php

// Cargamos clase 
include 'class/class.jugador.php';
include 'class/class.arrayJugadores.php';

// Cargamos modelo 
include 'models/model.create.php';

// Cargamos vista
include 'views/view.index.php';

?>