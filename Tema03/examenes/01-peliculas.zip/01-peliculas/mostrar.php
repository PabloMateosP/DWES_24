<?php

    //Cargamos libreria 
    include "lib/funciones.php";

    //Cargamos modelo
    include "models/model.mostrar.php";

    //Cargamos vista
    include "views/view.mostrar.php"

?>